package com.example.obsidianesp;

import com.example.obsidianesp.util.RenderUtils;
import com.example.obsidianesp.ObsidianEspBlockGroup;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2561;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import net.minecraft.class_4587;
import org.lwjgl.glfw.GLFW;
import me.shedaniel.autoconfig.AutoConfig;

public final class ObsidianEspMod
{
	private static final class_310 MC = class_310.method_1551();
	public static final Logger LOGGER = LoggerFactory.getLogger("ObsidianESP");

	private final ObsidianEspGroupManager groups;
	private final class_304 toggleKey;
	private boolean enabled = true;

	private int ticksElapsed = 0;

	public ObsidianEspMod()
	{
		LOGGER.info("Starting ObsidianESP with Config support...");

		groups = new ObsidianEspGroupManager();

		toggleKey = KeyBindingHelper.registerKeyBinding(new class_304(
				"key.obsidianesp.toggle",
				class_3675.class_307.field_1668,
				GLFW.GLFW_KEY_O,
				"ObsidianESP"
		));

		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			while(toggleKey.method_1436()) {
				setEnabled(!enabled);
				if (client.field_1724 != null) {
					client.field_1724.method_7353(
							class_2561.method_43470("ObsidianESP: " + (enabled ? "§aON" : "§cOFF")),
							true
					);
				}
			}
		});
	}

	public void setEnabled(boolean enabled)
	{
		if(this.enabled == enabled) return;
		this.enabled = enabled;

		if(!enabled)
			groups.blockGroups.forEach(ObsidianEspGroup::clear);
	}

	public void onUpdate()
	{
		if(!enabled) return;

		ObsidianConfig config = AutoConfig.getConfigHolder(ObsidianConfig.class).getConfig();

		ticksElapsed++;
		if (ticksElapsed < config.updateInterval) {
			return;
		}
		ticksElapsed = 0;

		if (MC.field_1687 == null || MC.field_1724 == null) return;

		groups.blockGroups.forEach(ObsidianEspGroup::clear);

		class_2338 playerPos = MC.field_1724.method_24515();
		int range = config.scanRange;

		for (int x = -range; x <= range; x++) {
			for (int y = -range; y <= range; y++) {
				for (int z = -range; z <= range; z++) {
					class_2338 pos = playerPos.method_10069(x, y, z);

					for (ObsidianEspBlockGroup group : groups.blockGroups) {
						group.addIfMatches(MC.field_1687.method_8320(pos), pos);
					}
				}
			}
		}
	}

	public void onRender(class_4587 matrixStack, float partialTicks)
	{
		if(!enabled) return;
		renderBoxes(matrixStack);
	}

	private void renderBoxes(class_4587 matrixStack)
	{
		for(ObsidianEspBlockGroup group : groups.blockGroups)
		{
			List<class_238> boxes = group.getBoxes();
			if (boxes.isEmpty()) continue;

			int quadsColor = group.getColorI(0x40);
			int linesColor = group.getColorI(0x80);

			RenderUtils.drawSolidBoxes(matrixStack, boxes, quadsColor, false);
			RenderUtils.drawOutlinedBoxes(matrixStack, boxes, linesColor, false);
		}
	}

	public boolean isEnabled() { return enabled; }

	public static ObsidianEspMod getInstance() {
		return ObsidianEspModInitializer.getInstance();
	}

	public ObsidianEspGroupManager getGroups() {
		return groups;
	}
}