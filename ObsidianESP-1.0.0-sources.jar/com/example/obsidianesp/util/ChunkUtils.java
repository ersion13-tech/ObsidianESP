package com.example.obsidianesp.util;

import java.util.Objects;
import java.util.stream.Stream;
import net.minecraft.class_1923;
import net.minecraft.class_2586;
import net.minecraft.class_2818;
import net.minecraft.class_310;

public enum ChunkUtils
{
	;

	private static final class_310 MC = class_310.method_1551();

	public static Stream<class_2586> getLoadedBlockEntities()
	{
		return getLoadedChunks()
				.flatMap(chunk -> chunk.method_12214().values().stream());
	}

	public static Stream<class_2818> getLoadedChunks()
	{
		int radius = Math.max(2, MC.field_1690.method_38521()) + 1;
		int diameter = radius * 2 + 1;

		class_1923 center = MC.field_1724.method_31476();
		class_1923 min = new class_1923(center.field_9181 - radius, center.field_9180 - radius);
		class_1923 max = new class_1923(center.field_9181 + radius, center.field_9180 + radius);

		return Stream.<class_1923> iterate(min, pos -> {
					int x = pos.field_9181;
					int z = pos.field_9180;

					x++;

					if(x > max.field_9181)
					{
						x = min.field_9181;
						z++;
					}

					return new class_1923(x, z);

				}).limit((long) diameter * diameter)
				.filter(c -> MC.field_1687.method_8393(c.field_9181, c.field_9180))
				.map(c -> MC.field_1687.method_8497(c.field_9181, c.field_9180))
				.filter(Objects::nonNull);
	}
}