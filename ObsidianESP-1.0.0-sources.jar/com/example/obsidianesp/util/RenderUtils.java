package com.example.obsidianesp.util;

import java.util.List;
import net.minecraft.class_1921;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4587.class_4665;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_5498;
import org.joml.Vector3f;
import com.mojang.blaze3d.platform.GlConst;
import com.mojang.blaze3d.systems.RenderSystem;
import com.example.obsidianesp.ObsidianEspRenderLayers;

public enum RenderUtils
{
	;

	private static final class_310 MC = class_310.method_1551();

	public static class_243 getCameraPos()
	{
		class_4184 camera = MC.field_1773.method_19418();
		return (camera == null) ? class_243.field_1353 : camera.method_19326();
	}

	public static class_4597.class_4598 getVCP()
	{
		return MC.method_22940().method_23000();
	}

	private static class_243 getTracerOrigin()
	{
		if (MC.field_1724 == null) return class_243.field_1353;
		class_243 start = MC.field_1724.method_5828(1.0F).method_1021(0.5);
		if(MC.field_1690.method_31044() == class_5498.field_26666)
			start = start.method_22882();

		return start;
	}

	public static void drawTracers(class_4587 matrices, float partialTicks,
								   List<class_243> ends, int color, boolean depthTest)
	{
		int depthFunc = depthTest ? GlConst.GL_LEQUAL : GlConst.GL_ALWAYS;
		RenderSystem.enableDepthTest();
		RenderSystem.depthFunc(depthFunc);

		class_4597.class_4598 vcp = getVCP();
		class_1921 layer = ObsidianEspRenderLayers.getLines(depthTest);
		class_4588 buffer = vcp.getBuffer(layer);

		class_243 start = getTracerOrigin();
		class_243 offset = getCameraPos().method_22882();
		for(class_243 end : ends)
			drawTraceLine(matrices, buffer, start, end.method_1019(offset), color);

		vcp.method_22994(layer);
	}

	// Вспомогательный метод для трейсеров (линии от глаз)
	private static void drawTraceLine(class_4587 matrices, class_4588 buffer,
									  class_243 start, class_243 end, int color)
	{
		class_4665 entry = matrices.method_23760();
		drawLine(entry, buffer, (float)start.field_1352, (float)start.field_1351, (float)start.field_1350,
				(float)end.field_1352, (float)end.field_1351, (float)end.field_1350, color);
	}

	public static void drawSolidBoxes(class_4587 matrices, List<class_238> boxes,
									  int color, boolean depthTest)
	{
		int depthFunc = depthTest ? GlConst.GL_LEQUAL : GlConst.GL_ALWAYS;
		RenderSystem.enableDepthTest();
		RenderSystem.depthFunc(depthFunc);

		class_4597.class_4598 vcp = getVCP();
		class_1921 layer = ObsidianEspRenderLayers.getQuads(depthTest);
		class_4588 buffer = vcp.getBuffer(layer);

		class_243 camOffset = getCameraPos().method_22882();
		for(class_238 box : boxes)
			drawSolidBox(matrices, buffer, box.method_997(camOffset), color);

		vcp.method_22994(layer);
	}

	public static void drawSolidBox(class_4587 matrices, class_4588 buffer,
									class_238 box, int color)
	{
		class_4587.class_4665 entry = matrices.method_23760();
		float x1 = (float)box.field_1323; float y1 = (float)box.field_1322; float z1 = (float)box.field_1321;
		float x2 = (float)box.field_1320; float y2 = (float)box.field_1325; float z2 = (float)box.field_1324;

		addQuad(entry, buffer, x1, y1, z1, x2, y1, z1, x2, y1, z2, x1, y1, z2, color);
		addQuad(entry, buffer, x1, y2, z1, x1, y2, z2, x2, y2, z2, x2, y2, z1, color);
		addQuad(entry, buffer, x1, y1, z1, x1, y2, z1, x2, y2, z1, x2, y1, z1, color);
		addQuad(entry, buffer, x2, y1, z1, x2, y2, z1, x2, y2, z2, x2, y1, z2, color);
		addQuad(entry, buffer, x1, y1, z2, x2, y1, z2, x2, y2, z2, x1, y2, z2, color);
		addQuad(entry, buffer, x1, y1, z1, x1, y1, z2, x1, y2, z2, x1, y2, z1, color);
	}

	private static void addQuad(class_4587.class_4665 entry, class_4588 buffer,
								float x1, float y1, float z1, float x2, float y2, float z2,
								float x3, float y3, float z3, float x4, float y4, float z4, int color) {
		buffer.method_56824(entry, x1, y1, z1).method_39415(color);
		buffer.method_56824(entry, x2, y2, z2).method_39415(color);
		buffer.method_56824(entry, x3, y3, z3).method_39415(color);
		buffer.method_56824(entry, x4, y4, z4).method_39415(color);
	}

	public static void drawOutlinedBoxes(class_4587 matrices, List<class_238> boxes,
										 int color, boolean depthTest)
	{
		int depthFunc = depthTest ? GlConst.GL_LEQUAL : GlConst.GL_ALWAYS;
		RenderSystem.enableDepthTest();
		RenderSystem.depthFunc(depthFunc);

		class_4597.class_4598 vcp = getVCP();
		class_1921 layer = ObsidianEspRenderLayers.getLines(depthTest);
		class_4588 buffer = vcp.getBuffer(layer);

		class_243 camOffset = getCameraPos().method_22882();
		for(class_238 box : boxes)
			drawOutlinedBox(matrices, buffer, box.method_997(camOffset), color);

		vcp.method_22994(layer);
	}

	public static void drawOutlinedBox(class_4587 matrices,
									   class_4588 buffer, class_238 box, int color)
	{
		class_4587.class_4665 entry = matrices.method_23760();
		float x1 = (float)box.field_1323; float y1 = (float)box.field_1322; float z1 = (float)box.field_1321;
		float x2 = (float)box.field_1320; float y2 = (float)box.field_1325; float z2 = (float)box.field_1324;

		drawLine(entry, buffer, x1, y1, z1, x2, y1, z1, color);
		drawLine(entry, buffer, x1, y1, z1, x1, y1, z2, color);
		drawLine(entry, buffer, x2, y1, z1, x2, y1, z2, color);
		drawLine(entry, buffer, x1, y1, z2, x2, y1, z2, color);

		drawLine(entry, buffer, x1, y2, z1, x2, y2, z1, color);
		drawLine(entry, buffer, x1, y2, z1, x1, y2, z2, color);
		drawLine(entry, buffer, x2, y2, z1, x2, y2, z2, color);
		drawLine(entry, buffer, x1, y2, z2, x2, y2, z2, color);

		drawLine(entry, buffer, x1, y1, z1, x1, y2, z1, color);
		drawLine(entry, buffer, x2, y1, z1, x2, y2, z1, color);
		drawLine(entry, buffer, x1, y1, z2, x1, y2, z2, color);
		drawLine(entry, buffer, x2, y1, z2, x2, y2, z2, color);
	}

	// Единственный и верный метод отрисовки линии
	public static void drawLine(class_4587.class_4665 entry, class_4588 buffer,
								float x1, float y1, float z1, float x2, float y2, float z2, int color) {
		Vector3f normal = new Vector3f(x2 - x1, y2 - y1, z2 - z1).normalize();
		buffer.method_56824(entry, x1, y1, z1).method_39415(color).method_60831(entry, normal.x, normal.y, normal.z);
		buffer.method_56824(entry, x2, y2, z2).method_39415(color).method_60831(entry, normal.x, normal.y, normal.z);
	}
}