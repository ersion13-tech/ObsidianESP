package com.example.obsidianesp.util;

import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_310;

public enum BlockUtils
{
	;

	private static final class_310 MC = class_310.method_1551();

	public static class_2680 getState(class_2338 pos)
	{
		return MC.field_1687.method_8320(pos);
	}

	private static class_265 getOutlineShape(class_2338 pos)
	{
		return getState(pos).method_26218(MC.field_1687, pos);
	}

	public static class_238 getBoundingBox(class_2338 pos)
	{
		return getOutlineShape(pos).method_1107().method_996(pos);
	}

	public static boolean canBeClicked(class_2338 pos)
	{
		return getOutlineShape(pos) != class_259.method_1073();
	}
}