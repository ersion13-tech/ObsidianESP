package com.example.obsidianesp.groups;

import com.example.obsidianesp.ObsidianEspBlockGroup;
import net.minecraft.class_2246;
import net.minecraft.class_2680;

public class ObsidianGroup extends ObsidianEspBlockGroup {

	public ObsidianGroup() {
		// Цвет: Фиолетовый (Alpha 255, Red 255, Green 0, Blue 255)
		super(255, 0, 255, 255);
	}

	@Override
	public boolean matches(class_2680 state) {
		return state.method_27852(class_2246.field_10540)
				|| state.method_27852(class_2246.field_22423)
				|| state.method_27852(class_2246.field_38420);
	}
}