package com.example.obsidianesp;

import java.util.OptionalDouble;
import net.minecraft.class_1921;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_4668;

public enum ObsidianEspRenderLayers
{
	;

	public static final class_1921.class_4687 LINES = class_1921
			.method_24049("obsidianesp:lines", class_290.field_29337,
					class_293.class_5596.field_27377, 1536, false, true,
					class_1921.class_4688.method_23598()
							.method_34578(class_1921.field_29433)
							.method_23609(new class_4668.class_4677(OptionalDouble.of(2)))
							.method_23607(class_1921.field_22241)
							.method_23615(class_1921.field_21370)
							.method_23610(class_1921.field_25643)
							.method_23616(class_1921.field_21349)
							.method_23604(class_1921.field_21348)
							.method_23603(class_1921.field_21345).method_23617(false));

	public static final class_1921.class_4687 ESP_LINES = class_1921
			.method_24049("obsidianesp:esp_lines", class_290.field_29337,
					class_293.class_5596.field_27377, 1536, false, true,
					class_1921.class_4688.method_23598()
							.method_34578(class_1921.field_29433)
							.method_23609(new class_4668.class_4677(OptionalDouble.of(2)))
							.method_23607(class_1921.field_22241)
							.method_23615(class_1921.field_21370)
							.method_23610(class_1921.field_25643)
							.method_23616(class_1921.field_21349)
							.method_23604(class_1921.field_21346)
							.method_23603(class_1921.field_21345).method_23617(false));

	public static final class_1921.class_4687 QUADS =
			class_1921.method_24049("obsidianesp:quads", class_290.field_1576,
					class_293.class_5596.field_27382, 1536, false, true,
					class_1921.class_4688.method_23598()
							.method_34578(class_1921.field_29442)
							.method_23615(class_1921.field_21370)
							.method_23604(class_1921.field_21348)
							.method_23617(false));

	public static final class_1921.class_4687 ESP_QUADS = class_1921
			.method_24049("obsidianesp:esp_quads", class_290.field_1576,
					class_293.class_5596.field_27382, 1536, false, true,
					class_1921.class_4688.method_23598()
							.method_34578(class_1921.field_29442)
							.method_23615(class_1921.field_21370)
							.method_23604(class_1921.field_21346)
							.method_23617(false));

	public static class_1921 getQuads(boolean depthTest)
	{
		return depthTest ? QUADS : ESP_QUADS;
	}

	public static class_1921 getLines(boolean depthTest)
	{
		return depthTest ? LINES : ESP_LINES;
	}
}