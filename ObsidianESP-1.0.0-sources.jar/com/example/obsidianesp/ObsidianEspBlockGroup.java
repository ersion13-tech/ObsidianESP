package com.example.obsidianesp;

import com.example.obsidianesp.util.BlockUtils;
import net.minecraft.class_2338;
import net.minecraft.class_2680;

public abstract class ObsidianEspBlockGroup extends ObsidianEspGroup {
	public ObsidianEspBlockGroup(int r, int g, int b, int a) {
		super(r, g, b, a);
	}

	public abstract boolean matches(class_2680 state);

	public final void addIfMatches(class_2680 state, class_2338 pos) {
		if (!matches(state))
			return;

		boxes.add(BlockUtils.getBoundingBox(pos));
	}
}